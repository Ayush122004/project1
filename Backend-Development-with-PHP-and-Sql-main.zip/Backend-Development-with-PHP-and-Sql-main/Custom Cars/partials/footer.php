<div class="container-fluid bg-dark text-light pl-5">
    <div class="row pt-3">
        <div class="col-md-4 col-sm-12">
            <h4>Download Our App</h4>
            <p>Terms & Conditions</p>
            
            <p>Privacy Policy</p>
        </div>

        <div class="col-md-4 col-sm-12">
            <h4>Contact Us</h4>
            <p>Phone Number - +91 9999990001</p>
            <p>E-Mail - rprithvi653@gmail.com</p>
        </div>

        <div class="col-md-4 col-sm-12">
            <h4>Car Modifications At</h4>
            <p>Haldia Institute Of Technology</p>
            <p>Central Computing Facility Lab</p>
        </div>

        <div class="col-md-12 text-center">
            <hr class="bg-light">
            <p class="mb-0">All Rights Reserved &copy;</p>
            <p>Made With Passion By Computer Society Of India</p>
        </div>
    </div>    

</div>